# Startup Failure Analytics

## Why Startups Fail? A Business Intelligence and Predictive Analytics Project

Startup Failure Analytics is an industry-level data analytics project built with Python, SQL, MySQL, and Power BI. It includes a 25,000-row realistic synthetic startup dataset, advanced MySQL analytics, modular Python data analytics, machine learning, explainability, and a Fortune 500-style Power BI dashboard blueprint.

This is not a web application. It does not use Flask, FastAPI, Streamlit, React, Node, Docker, AWS, or LLMs.

## Business Problem

Venture investors, accelerators, and corporate innovation teams need a systematic way to understand why startups fail. This project converts operating, financial, customer, market, founder, and investor signals into measurable insights.

## Project Structure

```text
Startup Failure Analytics/
|-- data/
|   |-- raw/
|   |-- processed/
|   `-- external/
|-- docs/
|-- notebooks/
|-- outputs/
|   |-- figures/
|   |-- models/
|   `-- tables/
|-- powerbi/
|   |-- dashboard_specs/
|   |-- data_model/
|   `-- measures/
|-- reports/
|-- sql/
|   |-- analytics/
|   |-- ddl/
|   `-- etl/
|-- src/
|   |-- analytics/
|   |-- config/
|   |-- data/
|   |-- features/
|   |-- models/
|   `-- visualization/
`-- tests/
```

## Dataset

Primary dataset:

`data/raw/startup_failure_dataset.csv`

Shape:

- 25,000 rows
- 38 requested columns
- Realistic distributions for funding, revenue, burn, runway, churn, ratings, market size, growth, risk, failure, and exit outcomes

Regenerate the dataset:

```powershell
python -m src.data.generate_dataset
```

## Technology Stack

Python libraries:

- Pandas
- NumPy
- Matplotlib
- Seaborn
- Plotly
- Scikit Learn
- XGBoost
- SciPy
- Statsmodels
- SHAP
- OpenPyXL

Database and BI:

- MySQL
- SQL
- Power BI

## How To Run

Install dependencies:

```powershell
pip install -r requirements.txt
```

Run the Python pipeline:

```powershell
python -m src.main
```

Expected outputs:

- `data/processed/startup_clean.csv`
- `data/processed/startup_features.csv`
- `data/processed/model_scoring_output.xlsx`
- `outputs/figures/*.png`
- `outputs/models/best_startup_failure_model.pkl`
- `outputs/tables/model_performance.xlsx`
- `outputs/tables/feature_importance.xlsx`
- `outputs/tables/startup_failure_predictions.xlsx`
- `outputs/tables/startup_failure_analytics_report.xlsx`

## MySQL Workflow

Run scripts in this order:

1. `sql/ddl/01_create_database.sql`
2. `sql/ddl/02_indexes.sql`
3. `sql/ddl/03_triggers.sql`
4. `sql/ddl/04_functions.sql`
5. `sql/ddl/05_stored_procedures.sql`
6. `sql/etl/02_load_staging.sql`
7. Load `data/raw/startup_failure_dataset.csv` into `stg_startup_failure`
8. `sql/etl/03_transform_to_mart.sql`
9. `sql/analytics/05_powerbi_views.sql`
10. `sql/analytics/04_failure_kpis.sql`
11. `sql/analytics/06_advanced_interview_questions.sql`

The Power BI report connects to `vw_startup_analytics`.

## Analytics Methodology

1. Data loading
2. Data validation
3. Missing value handling
4. Duplicate removal
5. Outlier detection and capping
6. Feature engineering
7. KPI and business metric calculation
8. EDA and visualization
9. Correlation analysis
10. Hypothesis testing
11. ML training and evaluation
12. SHAP explainability and feature importance
13. Report generation

## Machine Learning

Algorithms:

- Logistic Regression
- Decision Tree
- Random Forest
- Gradient Boosting
- XGBoost

Metrics:

- Accuracy
- Precision
- Recall
- F1
- ROC AUC
- Confusion Matrix
- Cross Validation
- Feature Importance
- SHAP

## Power BI Deliverable

The Power BI blueprint includes executive pages for:

- Executive Summary
- Startup Overview
- Funding Analysis
- Industry Analysis
- Country Analysis
- Failure Reasons
- Investor Analysis
- Founder Analysis
- Financial Analysis
- Risk Analysis
- ML Prediction Insights

Create `Startup_Failure_Analytics.pbix` in Power BI Desktop using the files in `powerbi/`.
