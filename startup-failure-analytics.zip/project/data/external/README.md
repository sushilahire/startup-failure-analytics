# External Data

Place third-party market, macroeconomic, funding, or benchmark datasets here.

Examples:

- Market sizing tables by sector and geography
- Interest rate or inflation indicators
- Venture funding benchmark data
- Public startup ecosystem reports

All external files should be documented in `docs/data_dictionary.md`.
