# Data Dictionary

Dataset: `data/raw/startup_failure_dataset.csv`

Rows: 25,000

| Column | Description |
| --- | --- |
| `Startup_ID` | Unique startup identifier |
| `Startup_Name` | Synthetic but realistic startup name |
| `Country` | Country of headquarters |
| `City` | City of headquarters |
| `Industry` | Startup industry segment |
| `Founded_Year` | Year founded |
| `Closed_Year` | Year closed, blank for operating or exited companies |
| `Funding_Amount` | Total capital raised in USD |
| `Funding_Rounds` | Number of funding rounds |
| `Investors` | Semicolon-separated investor names |
| `Employees` | Employee count |
| `Revenue` | Annual revenue in USD |
| `Expenses` | Annual expenses in USD |
| `Burn_Rate` | Monthly burn rate in USD |
| `Runway_Months` | Estimated months of runway |
| `Profit` | Annual profit in USD |
| `Loss` | Annual loss in USD |
| `CAC` | Customer acquisition cost |
| `LTV` | Customer lifetime value |
| `MRR` | Monthly recurring revenue |
| `ARR` | Annual recurring revenue |
| `Growth_Rate` | Annualized growth rate |
| `Market_Size` | Estimated addressable market size in USD millions |
| `Competition_Level` | Competition intensity score from 1 to 100 |
| `Founder_Experience` | Founder experience in years |
| `Business_Model` | Monetization model |
| `Employee_Satisfaction` | Employee satisfaction score from 1 to 5 |
| `Customer_Rating` | Customer rating from 1 to 5 |
| `Customer_Churn` | Monthly customer churn rate |
| `Website_Traffic` | Monthly website visits |
| `Monthly_Active_Users` | Monthly active users |
| `Product_Stage` | Product maturity stage |
| `Failure_Reason` | Primary failure reason or Not Applicable |
| `Exit_Type` | Closed, Acquired, IPO, Merged, or Still Operating |
| `Status` | Failed, Active, or Exited |
| `Survival_Years` | Years survived or years operating |
| `Risk_Score` | Synthetic failure risk score from 1 to 99 |
| `Failed` | Binary target, 1 for failed and 0 otherwise |

## Engineered Features

| Feature | Formula |
| --- | --- |
| `LTV_CAC_Ratio` | `LTV / CAC` |
| `Capital_Efficiency` | `Revenue / Funding_Amount` |
| `Funding_Per_Employee` | `Funding_Amount / Employees` |
| `Traffic_To_MAU_Rate` | `Monthly_Active_Users / Website_Traffic` |
| `Burn_Multiple` | `Burn_Rate / MRR` |
| `Revenue_Expense_Ratio` | `Revenue / Expenses` |
| `Calculated_Risk_Score` | Rule-based risk score recalculated in Python |
