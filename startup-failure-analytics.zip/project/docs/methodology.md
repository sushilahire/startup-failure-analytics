# Methodology

## 1. Data Preparation

The pipeline starts with a raw startup dataset and performs schema validation, type conversion, missing value handling, duplicate removal, and binary target creation.

## 2. Feature Engineering

Business-oriented indicators are created to make the analysis decision-ready:

- Burn To Revenue Ratio
- Runway Months
- Customers Per Month
- Funding Per Employee
- Capital Efficiency Score
- Market Competition Intensity

## 3. Exploratory Analysis

EDA focuses on failure rates by segment, operating efficiency, runway, and primary failure reasons. Visual outputs are saved to `outputs/figures/`.

## 4. Statistical Testing

The project uses:

- Mann-Whitney U test for burn efficiency differences between failed and surviving startups
- Chi-square test for relationship between industry and startup outcome
- Logistic regression using Statsmodels for interpretable directional effects

## 5. Predictive Modeling

Candidate models:

- Logistic Regression
- Decision Tree
- Random Forest
- Gradient Boosting
- XGBoost

Models are compared using accuracy and ROC-AUC. The best model is selected for explainability output.

## 6. Explainability

SHAP is used where supported. If SHAP cannot be calculated for the selected estimator, the pipeline falls back to model feature importance.

## 7. BI Delivery

Power BI connects to `vw_startup_analytics` and presents executive KPIs, segment diagnostics, investor exposure, financial performance, failure reasons, and predictive risk monitoring.
