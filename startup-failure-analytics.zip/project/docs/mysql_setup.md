# MySQL Setup

## Database Name

`startup_failure_analytics`

## Script Order

Run the SQL scripts in this sequence:

1. `sql/ddl/01_create_database.sql`
2. `sql/ddl/02_indexes.sql`
3. `sql/ddl/03_triggers.sql`
4. `sql/ddl/04_functions.sql`
5. `sql/ddl/05_stored_procedures.sql`
6. `sql/etl/02_load_staging.sql`
7. Load `data/raw/startup_failure_dataset.csv` into `stg_startup_failure`
8. `sql/etl/03_transform_to_mart.sql`
9. `sql/analytics/05_powerbi_views.sql`
10. `sql/analytics/04_failure_kpis.sql`
11. `sql/analytics/06_advanced_interview_questions.sql`

## Loading CSV Data

Edit the file path in `sql/etl/02_load_staging.sql` before running `LOAD DATA LOCAL INFILE`.

Example:

```sql
LOAD DATA LOCAL INFILE 'C:/Users/anike/Downloads/project/data/raw/startup_failure_sample.csv'
INTO TABLE stg_startup_outcomes
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;
```

## Power BI Connection

Connect Power BI Desktop to MySQL and import:

`startup_failure_analytics.vw_startup_analytics`
