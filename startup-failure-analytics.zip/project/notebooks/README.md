# Notebooks

Use this folder for exploratory analysis only.

Production logic should remain in `src/` so the pipeline is reproducible and testable.
