# Power BI Layer

This folder contains the dashboard blueprint for the Startup Failure Analytics report.

Power BI Desktop files (`.pbix`) are binary and should be created from these specifications:

1. Connect to MySQL database `startup_failure_analytics`.
2. Import view `vw_startup_analytics`.
3. Add DAX measures from `measures/startup_failure_measures.dax`.
4. Add calculated columns from `measures/calculated_columns.dax`.
5. Build report pages using `dashboard_specs/report_pages.md`.
6. Validate relationships against `data_model/star_schema.md`.

Recommended report name:

`Startup_Failure_Analytics.pbix`
