# Fortune 500 Power BI Dashboard Specification

## Design System

- Palette: executive navy `#0B1F3A`, slate `#5B6770`, light gray `#F4F6F8`, white `#FFFFFF`, success green `#2E7D32`, risk red `#B00020`, amber `#F4B400`.
- Typography: Segoe UI, concise page titles, KPI labels in uppercase.
- Layout: left slicer rail, top KPI strip, central analytical canvas, right insight panel where needed.
- Default slicers: Country, Industry, Founded Year, Business Model, Product Stage, Risk Band, Status.

## Page 1: Executive Summary

KPI cards:

- Total Startups
- Failed Startups
- Success Rate %
- Average Funding
- Average Survival Years
- Average Burn Rate
- Average Revenue
- High Risk Startups

Visuals:

- Failure Rate % by Industry
- Startup Count by Country
- Risk Band distribution
- Top Failure Reasons
- Funding vs Risk Score scatter

## Page 2: Startup Overview

Visuals:

- Startup count by Founded Year
- Startup count by Product Stage
- Status mix donut
- Business Model distribution
- Startup detail table with drill-through to startup profile

## Page 3: Funding Analysis

Visuals:

- Total Funding by Industry
- Average Funding by Country
- Funding Band distribution
- Funding Amount vs Survival Years scatter
- Top funded startups table

## Page 4: Industry Analysis

Visuals:

- Industry benchmark matrix
- Failure Rate % by Industry
- Average ARR by Industry
- Average Risk Score by Industry
- Drill-through enabled from Industry to failure reasons and startup list

## Page 5: Country Analysis

Visuals:

- Map: Total Startups by Country
- Country failure rate ranking
- Country funding exposure
- Country-industry heatmap
- Success Rate % trend by Founded Year

## Page 6: Failure Reasons

Visuals:

- Failure Reason ranked bar chart
- Failure Reason by Industry matrix
- Average Survival Years by Failure Reason
- Failure Reason by Product Stage
- Tooltip: CAC, LTV/CAC, Runway, Churn

## Page 7: Investor Analysis

Visuals:

- Investor funding exposure
- Investor failure rate
- Investor average startup survival
- Investor risk distribution
- Drill-through to investor portfolio detail

## Page 8: Founder Analysis

Visuals:

- Founder Experience vs Failure Rate
- Founder Experience by Industry
- Founder Experience vs Funding Amount
- Employee Satisfaction vs Founder Experience
- Founder risk segmentation table

## Page 9: Financial Analysis

Visuals:

- Revenue, Expenses, Profit, Loss cards
- Burn Rate by Industry
- Runway Band distribution
- LTV/CAC distribution
- MRR and ARR by Business Model

## Page 10: Risk Analysis

Visuals:

- Risk Score histogram
- Critical and High Risk startup table
- Runway vs Burn Rate scatter
- Churn vs Risk Score scatter
- Risk Band by Country and Industry

## Page 11: ML Prediction Insights

Visuals:

- Failure Probability table from Python scoring output
- Model comparison metrics
- Feature importance ranking
- SHAP importance ranking
- Confusion matrix visual

## Drill-Through Pages

- Startup Profile: selected startup financials, risk drivers, investors, product stage, predicted probability.
- Industry Detail: industry KPIs, failure reasons, top startups, funding exposure.
- Investor Detail: portfolio startups, failed count, risk score, funding exposure.
- Country Detail: city distribution, industry mix, funding and failure rates.

## Tooltip Pages

- Risk Tooltip: risk score, runway, churn, LTV/CAC, burn rate.
- Financial Tooltip: funding, revenue, expenses, profit, loss, ARR.
- Customer Tooltip: rating, churn, website traffic, monthly active users.

## KPI Card Formatting

- Green: success indicators and above-target performance.
- Red: failure rate, critical risk startups, high churn, short runway.
- Amber: medium risk, runway between 6 and 12 months.
- Navy: neutral business KPIs.
