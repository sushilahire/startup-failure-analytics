# Power BI Data Model

## Source

MySQL view:

`startup_failure_analytics.vw_startup_analytics`

## Recommended Model

For fast dashboard iteration, import the single analytical view. For governed enterprise deployment, expose the following star schema:

| Table | Grain | Description |
| --- | --- | --- |
| `fact_startup` | One row per startup | Startup operating metrics and outcome |
| `dim_industry` | One row per industry | Industry segmentation |
| `dim_country` | One row per country | Country segmentation |
| `dim_city` | One row per city | City segmentation |
| `dim_business_model` | One row per business model | Monetization segmentation |
| `dim_product_stage` | One row per product stage | Product maturity segmentation |
| `dim_failure_reason` | One row per failure reason | Failure root cause segmentation |
| `dim_exit_type` | One row per exit type | Exit outcome segmentation |

## Relationships

| From | To | Cardinality |
| --- | --- | --- |
| `fact_startup.industry_id` | `dim_industry.industry_id` | Many-to-one |
| `fact_startup.country_id` | `dim_country.country_id` | Many-to-one |
| `fact_startup.city_id` | `dim_city.city_id` | Many-to-one |
| `fact_startup.business_model_id` | `dim_business_model.business_model_id` | Many-to-one |
| `fact_startup.product_stage_id` | `dim_product_stage.product_stage_id` | Many-to-one |
| `fact_startup.failure_reason_id` | `dim_failure_reason.failure_reason_id` | Many-to-one |
| `fact_startup.exit_type_id` | `dim_exit_type.exit_type_id` | Many-to-one |

## Refresh Design

- Refresh frequency: weekly for executive dashboard, daily for active portfolio monitoring.
- Incremental refresh key: `startup_id` plus updated source timestamp when available.
- Data quality checks: non-null startup ID, valid outcome label, positive funding and burn fields.
