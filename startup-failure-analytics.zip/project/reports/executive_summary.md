# Executive Summary

## Project

Startup Failure Analytics: Why Startups Fail?

## Executive Message

Startup failure is rarely caused by a single issue. The strongest operational warning signs typically combine weak revenue traction, high burn intensity, limited runway, and crowded markets. This project provides a repeatable analytics system to quantify these risks and make intervention decisions more objective.

## Key Insights To Validate With Full Data

- Startups with high burn-to-revenue ratios should be prioritized for cash discipline review.
- Low runway and weak customer acquisition velocity are leading risk indicators.
- Failure reasons should be reviewed by industry because the operating pattern differs by sector.
- Funding stage analysis helps distinguish early product-market-fit risk from later scaling risk.

## Recommended Actions

| Priority | Recommendation | Business Rationale |
| --- | --- | --- |
| 1 | Build a monthly risk dashboard | Enables earlier identification of portfolio stress |
| 2 | Monitor burn-to-revenue ratio and runway | Links operating discipline to survival probability |
| 3 | Segment intervention by failure driver | Avoids generic support programs |
| 4 | Combine model output with partner judgment | Improves decisions without replacing expert review |

## Deliverables

- Python analytics pipeline
- MySQL data mart and analytical views
- Power BI dashboard specification
- Executive report framework
- Data dictionary and methodology documentation
