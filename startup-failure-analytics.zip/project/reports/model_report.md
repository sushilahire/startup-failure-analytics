# Predictive Model Report

## Objective

Predict startup failure risk using operating, funding, market, and traction indicators.

## Target Variable

`is_failed`

- `1`: Failed
- `0`: Survived

## Candidate Models

| Model | Purpose |
| --- | --- |
| Logistic Regression | Interpretable baseline |
| Decision Tree | Transparent nonlinear benchmark |
| Random Forest | Nonlinear benchmark |
| Gradient Boosting | Sequential boosting benchmark |
| XGBoost | Gradient boosting performance candidate |

## Evaluation Metrics

- Accuracy
- ROC-AUC
- Confusion matrix
- Cross-validation ROC-AUC
- Precision, recall, and F1-score

## Explainability

The pipeline exports `outputs/tables/feature_importance.xlsx`, using SHAP where supported and model feature importance as a fallback.

## Model Governance Notes

- The included sample dataset is intentionally small and should be replaced before drawing real conclusions.
- Real deployment should include out-of-time validation and model drift monitoring.
- Model outputs should support human decision-making, not automate funding decisions.
