# Power BI Report Brief

## Report Name

`Startup_Failure_Analytics.pbix`

## Audience

Investment committees, accelerator leaders, strategy teams, and portfolio operations teams.

## Page Design

| Page | Purpose |
| --- | --- |
| Executive Summary | Portfolio-level performance and failure concentration |
| Startup Overview | Startup mix, status, product maturity, and detail table |
| Funding Analysis | Capital exposure and funding distribution |
| Industry Analysis | Industry benchmarks and drill-through |
| Country Analysis | Geographic performance and concentration |
| Failure Reasons | Root cause analysis by industry and product stage |
| Investor Analysis | Investor exposure and portfolio risk |
| Founder Analysis | Founder experience and people indicators |
| Financial Analysis | Revenue, burn, profit, loss, ARR, and MRR |
| Risk Analysis | Risk bands, runway, churn, and critical startups |
| ML Prediction Insights | Model outputs, feature importance, SHAP, and confusion matrix |

## Required Data Source

MySQL view:

`startup_failure_analytics.vw_startup_analytics`

## Required Measures

Use DAX measures from:

`powerbi/measures/startup_failure_measures.dax`
