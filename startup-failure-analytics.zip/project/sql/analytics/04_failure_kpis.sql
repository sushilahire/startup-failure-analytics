USE startup_failure_analytics;

SELECT
    COUNT(*) AS total_startups,
    SUM(failed) AS failed_startups,
    ROUND((1 - AVG(failed)) * 100, 2) AS success_rate_pct,
    ROUND(AVG(funding_amount), 2) AS avg_funding,
    ROUND(AVG(survival_years), 2) AS avg_survival_years,
    ROUND(AVG(burn_rate), 2) AS avg_burn_rate,
    ROUND(AVG(revenue), 2) AS avg_revenue
FROM fact_startup;

WITH industry_failure AS (
    SELECT
        i.industry_name,
        COUNT(*) AS total_startups,
        SUM(f.failed) AS failed_startups,
        AVG(f.failed) AS failure_rate
    FROM fact_startup f
    JOIN dim_industry i ON f.industry_id = i.industry_id
    GROUP BY i.industry_name
)
SELECT
    industry_name,
    total_startups,
    failed_startups,
    ROUND(failure_rate * 100, 2) AS failure_rate_pct,
    RANK() OVER (ORDER BY failure_rate DESC) AS failure_rank
FROM industry_failure;

WITH ranked_reasons AS (
    SELECT
        fr.failure_reason,
        COUNT(*) AS failed_startups,
        DENSE_RANK() OVER (ORDER BY COUNT(*) DESC) AS reason_rank
    FROM fact_startup f
    JOIN dim_failure_reason fr ON f.failure_reason_id = fr.failure_reason_id
    WHERE f.failed = 1
    GROUP BY fr.failure_reason
)
SELECT * FROM ranked_reasons WHERE reason_rank <= 10;
