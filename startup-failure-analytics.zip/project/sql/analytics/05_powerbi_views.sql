USE startup_failure_analytics;

CREATE OR REPLACE VIEW vw_startup_analytics AS
SELECT
    f.startup_id,
    f.startup_name,
    c.country_name AS country,
    city.city_name AS city,
    i.industry_name AS industry,
    bm.business_model,
    ps.product_stage,
    fr.failure_reason,
    et.exit_type,
    f.founded_year,
    f.closed_year,
    f.funding_amount,
    f.funding_rounds,
    f.investors,
    f.employees,
    f.revenue,
    f.expenses,
    f.burn_rate,
    f.runway_months,
    f.profit,
    f.loss,
    f.cac,
    f.ltv,
    fn_ltv_cac_ratio(f.ltv, f.cac) AS ltv_cac_ratio,
    f.mrr,
    f.arr,
    f.growth_rate,
    f.market_size,
    f.competition_level,
    f.founder_experience,
    f.employee_satisfaction,
    f.customer_rating,
    f.customer_churn,
    f.website_traffic,
    f.monthly_active_users,
    f.status,
    f.survival_years,
    f.risk_score,
    fn_risk_band(f.risk_score) AS risk_band,
    f.failed,
    f.revenue / NULLIF(f.expenses, 0) AS revenue_expense_ratio,
    f.monthly_active_users / NULLIF(f.website_traffic, 0) AS traffic_to_mau_rate,
    f.funding_amount / NULLIF(f.employees, 0) AS funding_per_employee,
    fn_capital_efficiency(f.revenue, f.funding_amount) AS capital_efficiency
FROM fact_startup f
JOIN dim_country c ON f.country_id = c.country_id
JOIN dim_city city ON f.city_id = city.city_id
JOIN dim_industry i ON f.industry_id = i.industry_id
JOIN dim_business_model bm ON f.business_model_id = bm.business_model_id
JOIN dim_product_stage ps ON f.product_stage_id = ps.product_stage_id
JOIN dim_failure_reason fr ON f.failure_reason_id = fr.failure_reason_id
JOIN dim_exit_type et ON f.exit_type_id = et.exit_type_id;

CREATE OR REPLACE VIEW vw_industry_benchmark AS
SELECT
    industry,
    COUNT(*) AS total_startups,
    SUM(failed) AS failed_startups,
    ROUND(AVG(failed) * 100, 2) AS failure_rate_pct,
    ROUND(AVG(funding_amount), 2) AS avg_funding,
    ROUND(AVG(revenue), 2) AS avg_revenue,
    ROUND(AVG(burn_rate), 2) AS avg_burn_rate,
    ROUND(AVG(runway_months), 2) AS avg_runway_months,
    ROUND(AVG(survival_years), 2) AS avg_survival_years,
    ROUND(AVG(risk_score), 2) AS avg_risk_score
FROM vw_startup_analytics
GROUP BY industry;

CREATE OR REPLACE VIEW vw_investor_exposure AS
SELECT
    investor_name,
    COUNT(*) AS startup_count,
    SUM(failed) AS failed_count,
    ROUND(AVG(failed) * 100, 2) AS failure_rate_pct,
    ROUND(SUM(funding_amount), 2) AS total_funding_exposure,
    ROUND(AVG(risk_score), 2) AS avg_risk_score
FROM (
    SELECT
        startup_id,
        funding_amount,
        failed,
        risk_score,
        TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(investors, ';', numbers.n), ';', -1)) AS investor_name
    FROM vw_startup_analytics
    JOIN (
        SELECT 1 n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6
    ) numbers ON CHAR_LENGTH(investors) - CHAR_LENGTH(REPLACE(investors, ';', '')) >= numbers.n - 1
) investor_split
GROUP BY investor_name;
