USE startup_failure_analytics;

-- 01. Which industries have the highest failure rate after controlling for minimum sample size?
SELECT industry, total_startups, failed_startups, failure_rate_pct
FROM vw_industry_benchmark
WHERE total_startups >= 500
ORDER BY failure_rate_pct DESC;

-- 02. Rank countries by startup success rate and average funding.
WITH country_metrics AS (
    SELECT country, COUNT(*) total_startups, AVG(failed) failure_rate, AVG(funding_amount) avg_funding
    FROM vw_startup_analytics
    GROUP BY country
)
SELECT country, total_startups, ROUND((1 - failure_rate) * 100, 2) success_rate_pct, ROUND(avg_funding, 2) avg_funding,
       RANK() OVER (ORDER BY (1 - failure_rate) DESC, avg_funding DESC) country_rank
FROM country_metrics;

-- 03. Identify high-risk active startups with short runway and weak LTV/CAC.
SELECT startup_id, startup_name, country, industry, risk_score, runway_months, ltv_cac_ratio, growth_rate
FROM vw_startup_analytics
WHERE status = 'Active' AND risk_score >= 75 AND runway_months < 12 AND ltv_cac_ratio < 3
ORDER BY risk_score DESC;

-- 04. Which failure reasons dominate by industry?
WITH reason_mix AS (
    SELECT industry, failure_reason, COUNT(*) failed_count,
           ROW_NUMBER() OVER (PARTITION BY industry ORDER BY COUNT(*) DESC) rn
    FROM vw_startup_analytics
    WHERE failed = 1
    GROUP BY industry, failure_reason
)
SELECT industry, failure_reason, failed_count FROM reason_mix WHERE rn <= 3;

-- 05. Compare median-like survival by product stage using percent rank.
WITH survival_rank AS (
    SELECT product_stage, survival_years,
           PERCENT_RANK() OVER (PARTITION BY product_stage ORDER BY survival_years) pct_rank
    FROM vw_startup_analytics
)
SELECT product_stage, ROUND(AVG(survival_years), 2) approx_median_survival
FROM survival_rank
WHERE pct_rank BETWEEN 0.45 AND 0.55
GROUP BY product_stage;

-- 06. Which investors have the highest failed funding exposure?
SELECT investor_name, startup_count, failed_count, total_funding_exposure, failure_rate_pct
FROM vw_investor_exposure
WHERE startup_count >= 100
ORDER BY total_funding_exposure DESC;

-- 07. What is the average burn multiple by industry?
SELECT industry, ROUND(AVG(burn_rate / NULLIF(mrr, 0)), 2) avg_burn_multiple
FROM vw_startup_analytics
GROUP BY industry
ORDER BY avg_burn_multiple DESC;

-- 08. Find startups with revenue growth but deteriorating capital efficiency.
SELECT startup_id, startup_name, industry, growth_rate, capital_efficiency, burn_rate
FROM vw_startup_analytics
WHERE growth_rate > 0.5 AND capital_efficiency < 0.15
ORDER BY growth_rate DESC;

-- 09. Identify country-industry combinations with unusually high risk.
SELECT country, industry, COUNT(*) startup_count, ROUND(AVG(risk_score), 2) avg_risk
FROM vw_startup_analytics
GROUP BY country, industry
HAVING COUNT(*) >= 100
ORDER BY avg_risk DESC;

-- 10. Calculate cumulative funding share by industry.
SELECT industry, funding_amount,
       SUM(funding_amount) OVER (PARTITION BY industry ORDER BY funding_amount DESC) AS cumulative_industry_funding
FROM vw_startup_analytics;

-- 11. Which startups are in the top decile of risk within their industry?
WITH deciles AS (
    SELECT startup_id, startup_name, industry, risk_score,
           NTILE(10) OVER (PARTITION BY industry ORDER BY risk_score DESC) risk_decile
    FROM vw_startup_analytics
)
SELECT * FROM deciles WHERE risk_decile = 1;

-- 12. Compare failed vs active startups by unit economics.
SELECT status, ROUND(AVG(ltv_cac_ratio), 2) avg_ltv_cac, ROUND(AVG(customer_churn), 4) avg_churn,
       ROUND(AVG(growth_rate), 4) avg_growth
FROM vw_startup_analytics
GROUP BY status;

-- 13. Which cities produce the most exited startups?
SELECT country, city, COUNT(*) exited_startups
FROM vw_startup_analytics
WHERE status = 'Exited'
GROUP BY country, city
ORDER BY exited_startups DESC;

-- 14. Determine the capital efficiency quartile for each startup.
SELECT startup_id, startup_name, industry, capital_efficiency,
       NTILE(4) OVER (ORDER BY capital_efficiency DESC) capital_efficiency_quartile
FROM vw_startup_analytics;

-- 15. Which business models have the highest average ARR?
SELECT business_model, COUNT(*) startup_count, ROUND(AVG(arr), 2) avg_arr
FROM vw_startup_analytics
GROUP BY business_model
ORDER BY avg_arr DESC;

-- 16. Find startups where expenses exceed revenue by more than 5x.
SELECT startup_id, startup_name, revenue, expenses, ROUND(expenses / NULLIF(revenue, 0), 2) expense_revenue_multiple
FROM vw_startup_analytics
WHERE expenses / NULLIF(revenue, 0) > 5
ORDER BY expense_revenue_multiple DESC;

-- 17. Rank industries by average founder experience among successful startups.
SELECT industry, ROUND(AVG(founder_experience), 2) avg_founder_experience,
       RANK() OVER (ORDER BY AVG(founder_experience) DESC) experience_rank
FROM vw_startup_analytics
WHERE failed = 0
GROUP BY industry;

-- 18. Measure failure rate by founding cohort.
SELECT founded_year, COUNT(*) total_startups, ROUND(AVG(failed) * 100, 2) failure_rate_pct
FROM vw_startup_analytics
GROUP BY founded_year
ORDER BY founded_year;

-- 19. Find industry leaders by monthly active users.
WITH leaders AS (
    SELECT startup_id, startup_name, industry, monthly_active_users,
           ROW_NUMBER() OVER (PARTITION BY industry ORDER BY monthly_active_users DESC) rn
    FROM vw_startup_analytics
)
SELECT * FROM leaders WHERE rn <= 5;

-- 20. What percentage of failed startups had runway below 12 months?
SELECT ROUND(AVG(runway_months < 12) * 100, 2) AS failed_with_low_runway_pct
FROM vw_startup_analytics
WHERE failed = 1;

-- 21. Compare average customer rating by failure reason.
SELECT failure_reason, ROUND(AVG(customer_rating), 2) avg_customer_rating, COUNT(*) failed_startups
FROM vw_startup_analytics
WHERE failed = 1
GROUP BY failure_reason
ORDER BY avg_customer_rating ASC;

-- 22. Identify startups with strong satisfaction but weak customer ratings.
SELECT startup_id, startup_name, employee_satisfaction, customer_rating, risk_score
FROM vw_startup_analytics
WHERE employee_satisfaction >= 4.2 AND customer_rating <= 2.5
ORDER BY risk_score DESC;

-- 23. Rank investors by average startup survival years.
SELECT investor_name, startup_count, ROUND(AVG(s.survival_years), 2) avg_survival_years
FROM vw_investor_exposure e
JOIN vw_startup_analytics s ON LOCATE(e.investor_name, s.investors) > 0
GROUP BY investor_name, startup_count
HAVING startup_count >= 100
ORDER BY avg_survival_years DESC;

-- 24. Calculate moving average failure rate by founding year.
WITH cohort AS (
    SELECT founded_year, AVG(failed) failure_rate
    FROM vw_startup_analytics
    GROUP BY founded_year
)
SELECT founded_year, ROUND(failure_rate * 100, 2) failure_rate_pct,
       ROUND(AVG(failure_rate) OVER (ORDER BY founded_year ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) * 100, 2) moving_avg_failure_rate_pct
FROM cohort;

-- 25. Segment startups into risk bands.
SELECT risk_band, COUNT(*) startup_count, ROUND(AVG(failed) * 100, 2) actual_failure_rate_pct
FROM vw_startup_analytics
GROUP BY risk_band
ORDER BY actual_failure_rate_pct DESC;

-- 26. Which product stages have the weakest runway?
SELECT product_stage, ROUND(AVG(runway_months), 2) avg_runway_months, ROUND(AVG(risk_score), 2) avg_risk
FROM vw_startup_analytics
GROUP BY product_stage
ORDER BY avg_runway_months ASC;

-- 27. Identify companies with abnormal funding per employee.
WITH funding_stats AS (
    SELECT AVG(funding_per_employee) avg_fpe, STDDEV(funding_per_employee) sd_fpe
    FROM vw_startup_analytics
)
SELECT startup_id, startup_name, funding_per_employee
FROM vw_startup_analytics, funding_stats
WHERE funding_per_employee > avg_fpe + 3 * sd_fpe
ORDER BY funding_per_employee DESC;

-- 28. Find industries where churn explains failure risk.
SELECT industry, ROUND(AVG(customer_churn), 4) avg_churn, ROUND(AVG(failed) * 100, 2) failure_rate_pct
FROM vw_startup_analytics
GROUP BY industry
ORDER BY avg_churn DESC;

-- 29. Compare IPO/acquired exits against active companies.
SELECT exit_type, COUNT(*) startups, ROUND(AVG(funding_amount), 2) avg_funding, ROUND(AVG(growth_rate), 4) avg_growth
FROM vw_startup_analytics
WHERE exit_type IN ('IPO', 'Acquired', 'Still Operating')
GROUP BY exit_type;

-- 30. Which startups have high traffic but poor conversion to MAU?
SELECT startup_id, startup_name, website_traffic, monthly_active_users, traffic_to_mau_rate
FROM vw_startup_analytics
WHERE website_traffic >= 100000 AND traffic_to_mau_rate < 0.05
ORDER BY website_traffic DESC;

-- 31. Determine funding concentration using cumulative percent by country.
SELECT country, startup_id, startup_name, funding_amount,
       SUM(funding_amount) OVER (PARTITION BY country ORDER BY funding_amount DESC)
       / SUM(funding_amount) OVER (PARTITION BY country) AS cumulative_funding_pct
FROM vw_startup_analytics;

-- 32. Which failure reasons are associated with shortest survival?
SELECT failure_reason, COUNT(*) failed_startups, ROUND(AVG(survival_years), 2) avg_survival_years
FROM vw_startup_analytics
WHERE failed = 1
GROUP BY failure_reason
ORDER BY avg_survival_years ASC;

-- 33. Find companies with negative growth and high burn.
SELECT startup_id, startup_name, industry, growth_rate, burn_rate, runway_months
FROM vw_startup_analytics
WHERE growth_rate < 0 AND burn_rate > (SELECT AVG(burn_rate) FROM vw_startup_analytics)
ORDER BY burn_rate DESC;

-- 34. Compare business model risk.
SELECT business_model, COUNT(*) startups, ROUND(AVG(risk_score), 2) avg_risk_score, ROUND(AVG(failed) * 100, 2) failure_rate_pct
FROM vw_startup_analytics
GROUP BY business_model
ORDER BY failure_rate_pct DESC;

-- 35. Identify top 10 startups by ARR within each country.
WITH country_arr AS (
    SELECT country, startup_id, startup_name, arr,
           ROW_NUMBER() OVER (PARTITION BY country ORDER BY arr DESC) rn
    FROM vw_startup_analytics
)
SELECT * FROM country_arr WHERE rn <= 10;

-- 36. Create a risk-adjusted funding efficiency score.
SELECT startup_id, startup_name, industry,
       ROUND(capital_efficiency / NULLIF(risk_score, 0) * 100, 4) AS risk_adjusted_efficiency
FROM vw_startup_analytics
ORDER BY risk_adjusted_efficiency DESC;

-- 37. Which cohorts attracted the most average funding?
SELECT founded_year, COUNT(*) startups, ROUND(AVG(funding_amount), 2) avg_funding
FROM vw_startup_analytics
GROUP BY founded_year
ORDER BY avg_funding DESC;

-- 38. Identify high growth startups that still failed.
SELECT startup_id, startup_name, industry, growth_rate, failure_reason, risk_score
FROM vw_startup_analytics
WHERE failed = 1 AND growth_rate >= 0.5
ORDER BY growth_rate DESC;

-- 39. What is the employee satisfaction gap between failed and active startups?
SELECT failed, ROUND(AVG(employee_satisfaction), 2) avg_employee_satisfaction
FROM vw_startup_analytics
GROUP BY failed;

-- 40. Which active startups are closest to failure profile by risk band and low runway?
SELECT startup_id, startup_name, country, industry, risk_band, risk_score, runway_months, failure_reason
FROM vw_startup_analytics
WHERE status = 'Active' AND risk_band IN ('High', 'Critical') AND runway_months <= 18
ORDER BY risk_score DESC, runway_months ASC;
