DROP DATABASE IF EXISTS startup_failure_analytics;
CREATE DATABASE startup_failure_analytics;
USE startup_failure_analytics;

CREATE TABLE dim_country (
    country_id INT AUTO_INCREMENT PRIMARY KEY,
    country_name VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE dim_city (
    city_id INT AUTO_INCREMENT PRIMARY KEY,
    city_name VARCHAR(100) NOT NULL,
    country_id INT NOT NULL,
    UNIQUE KEY uq_city_country (city_name, country_id),
    CONSTRAINT fk_city_country FOREIGN KEY (country_id) REFERENCES dim_country(country_id)
);

CREATE TABLE dim_industry (
    industry_id INT AUTO_INCREMENT PRIMARY KEY,
    industry_name VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE dim_business_model (
    business_model_id INT AUTO_INCREMENT PRIMARY KEY,
    business_model VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE dim_product_stage (
    product_stage_id INT AUTO_INCREMENT PRIMARY KEY,
    product_stage VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE dim_failure_reason (
    failure_reason_id INT AUTO_INCREMENT PRIMARY KEY,
    failure_reason VARCHAR(150) NOT NULL UNIQUE
);

CREATE TABLE dim_exit_type (
    exit_type_id INT AUTO_INCREMENT PRIMARY KEY,
    exit_type VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE fact_startup (
    startup_id VARCHAR(20) PRIMARY KEY,
    startup_name VARCHAR(150) NOT NULL,
    country_id INT NOT NULL,
    city_id INT NOT NULL,
    industry_id INT NOT NULL,
    business_model_id INT NOT NULL,
    product_stage_id INT NOT NULL,
    failure_reason_id INT NOT NULL,
    exit_type_id INT NOT NULL,
    founded_year SMALLINT NOT NULL,
    closed_year SMALLINT NULL,
    funding_amount DECIMAL(18,2) NOT NULL,
    funding_rounds INT NOT NULL,
    investors TEXT NOT NULL,
    employees INT NOT NULL,
    revenue DECIMAL(18,2) NOT NULL,
    expenses DECIMAL(18,2) NOT NULL,
    burn_rate DECIMAL(18,2) NOT NULL,
    runway_months DECIMAL(8,2) NOT NULL,
    profit DECIMAL(18,2) NOT NULL,
    loss DECIMAL(18,2) NOT NULL,
    cac DECIMAL(12,2) NOT NULL,
    ltv DECIMAL(12,2) NOT NULL,
    mrr DECIMAL(18,2) NOT NULL,
    arr DECIMAL(18,2) NOT NULL,
    growth_rate DECIMAL(8,4) NOT NULL,
    market_size DECIMAL(18,2) NOT NULL,
    competition_level INT NOT NULL,
    founder_experience DECIMAL(6,2) NOT NULL,
    employee_satisfaction DECIMAL(4,2) NOT NULL,
    customer_rating DECIMAL(4,2) NOT NULL,
    customer_churn DECIMAL(8,4) NOT NULL,
    website_traffic BIGINT NOT NULL,
    monthly_active_users BIGINT NOT NULL,
    status VARCHAR(30) NOT NULL,
    survival_years DECIMAL(6,2) NOT NULL,
    risk_score DECIMAL(6,2) NOT NULL,
    failed TINYINT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_startup_country FOREIGN KEY (country_id) REFERENCES dim_country(country_id),
    CONSTRAINT fk_startup_city FOREIGN KEY (city_id) REFERENCES dim_city(city_id),
    CONSTRAINT fk_startup_industry FOREIGN KEY (industry_id) REFERENCES dim_industry(industry_id),
    CONSTRAINT fk_startup_business_model FOREIGN KEY (business_model_id) REFERENCES dim_business_model(business_model_id),
    CONSTRAINT fk_startup_product_stage FOREIGN KEY (product_stage_id) REFERENCES dim_product_stage(product_stage_id),
    CONSTRAINT fk_startup_failure_reason FOREIGN KEY (failure_reason_id) REFERENCES dim_failure_reason(failure_reason_id),
    CONSTRAINT fk_startup_exit_type FOREIGN KEY (exit_type_id) REFERENCES dim_exit_type(exit_type_id),
    CONSTRAINT chk_failed CHECK (failed IN (0, 1)),
    CONSTRAINT chk_years CHECK (founded_year BETWEEN 1990 AND 2030),
    CONSTRAINT chk_financials CHECK (funding_amount >= 0 AND revenue >= 0 AND expenses >= 0)
);

CREATE TABLE startup_audit_log (
    audit_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    startup_id VARCHAR(20) NOT NULL,
    action_type VARCHAR(20) NOT NULL,
    old_risk_score DECIMAL(6,2),
    new_risk_score DECIMAL(6,2),
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
