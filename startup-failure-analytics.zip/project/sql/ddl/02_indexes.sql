USE startup_failure_analytics;

CREATE INDEX idx_startup_failed ON fact_startup (failed);
CREATE INDEX idx_startup_status ON fact_startup (status);
CREATE INDEX idx_startup_country_industry ON fact_startup (country_id, industry_id);
CREATE INDEX idx_startup_industry_failed ON fact_startup (industry_id, failed);
CREATE INDEX idx_startup_risk_score ON fact_startup (risk_score DESC);
CREATE INDEX idx_startup_funding ON fact_startup (funding_amount DESC);
CREATE INDEX idx_startup_runway ON fact_startup (runway_months);
CREATE INDEX idx_startup_growth ON fact_startup (growth_rate DESC);
CREATE INDEX idx_startup_founded_year ON fact_startup (founded_year);
CREATE FULLTEXT INDEX ftx_startup_investors ON fact_startup (investors);
