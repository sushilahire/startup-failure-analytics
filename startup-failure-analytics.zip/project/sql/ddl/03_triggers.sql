USE startup_failure_analytics;

DELIMITER //

CREATE TRIGGER trg_fact_startup_before_insert
BEFORE INSERT ON fact_startup
FOR EACH ROW
BEGIN
    IF NEW.arr <> NEW.mrr * 12 THEN
        SET NEW.arr = NEW.mrr * 12;
    END IF;

    IF NEW.failed = 1 AND NEW.closed_year IS NULL THEN
        SET NEW.closed_year = NEW.founded_year + CEIL(NEW.survival_years);
    END IF;
END//

CREATE TRIGGER trg_fact_startup_after_update
AFTER UPDATE ON fact_startup
FOR EACH ROW
BEGIN
    IF OLD.risk_score <> NEW.risk_score THEN
        INSERT INTO startup_audit_log (startup_id, action_type, old_risk_score, new_risk_score)
        VALUES (NEW.startup_id, 'RISK_UPDATE', OLD.risk_score, NEW.risk_score);
    END IF;
END//

DELIMITER ;
