USE startup_failure_analytics;

DELIMITER //

CREATE FUNCTION fn_ltv_cac_ratio(ltv DECIMAL(12,2), cac DECIMAL(12,2))
RETURNS DECIMAL(12,4)
DETERMINISTIC
BEGIN
    RETURN ltv / NULLIF(cac, 0);
END//

CREATE FUNCTION fn_risk_band(risk_score DECIMAL(6,2))
RETURNS VARCHAR(20)
DETERMINISTIC
BEGIN
    RETURN CASE
        WHEN risk_score >= 75 THEN 'Critical'
        WHEN risk_score >= 55 THEN 'High'
        WHEN risk_score >= 35 THEN 'Medium'
        ELSE 'Low'
    END;
END//

CREATE FUNCTION fn_capital_efficiency(revenue DECIMAL(18,2), funding_amount DECIMAL(18,2))
RETURNS DECIMAL(12,4)
DETERMINISTIC
BEGIN
    RETURN revenue / NULLIF(funding_amount, 0);
END//

DELIMITER ;
