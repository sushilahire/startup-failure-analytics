USE startup_failure_analytics;

DELIMITER //

CREATE PROCEDURE sp_country_failure_summary(IN p_country VARCHAR(100))
BEGIN
    SELECT
        c.country_name,
        COUNT(*) AS total_startups,
        SUM(f.failed) AS failed_startups,
        ROUND(AVG(f.failed) * 100, 2) AS failure_rate_pct,
        ROUND(AVG(f.funding_amount), 2) AS avg_funding,
        ROUND(AVG(f.survival_years), 2) AS avg_survival_years,
        ROUND(AVG(f.risk_score), 2) AS avg_risk_score
    FROM fact_startup f
    JOIN dim_country c ON f.country_id = c.country_id
    WHERE c.country_name = p_country
    GROUP BY c.country_name;
END//

CREATE PROCEDURE sp_high_risk_startups(IN p_min_risk DECIMAL(6,2), IN p_limit INT)
BEGIN
    SELECT
        f.startup_id,
        f.startup_name,
        c.country_name,
        i.industry_name,
        f.risk_score,
        fn_risk_band(f.risk_score) AS risk_band,
        f.runway_months,
        f.burn_rate,
        f.growth_rate
    FROM fact_startup f
    JOIN dim_country c ON f.country_id = c.country_id
    JOIN dim_industry i ON f.industry_id = i.industry_id
    WHERE f.risk_score >= p_min_risk
    ORDER BY f.risk_score DESC, f.runway_months ASC
    LIMIT p_limit;
END//

CREATE PROCEDURE sp_recalculate_risk_score(IN p_startup_id VARCHAR(20))
BEGIN
    UPDATE fact_startup
    SET risk_score = LEAST(
        99,
        GREATEST(
            1,
            20
            + (customer_churn * 35)
            + (competition_level * 0.20)
            + IF(runway_months < 12, 18, 0)
            + IF(growth_rate < 0, 12, 0)
            + IF(fn_ltv_cac_ratio(ltv, cac) < 3, 10, 0)
        )
    )
    WHERE startup_id = p_startup_id;
END//

DELIMITER ;
