USE startup_failure_analytics;

DROP TABLE IF EXISTS stg_startup_failure;

CREATE TABLE stg_startup_failure (
    Startup_ID VARCHAR(20),
    Startup_Name VARCHAR(150),
    Country VARCHAR(100),
    City VARCHAR(100),
    Industry VARCHAR(100),
    Founded_Year SMALLINT,
    Closed_Year SMALLINT NULL,
    Funding_Amount DECIMAL(18,2),
    Funding_Rounds INT,
    Investors TEXT,
    Employees INT,
    Revenue DECIMAL(18,2),
    Expenses DECIMAL(18,2),
    Burn_Rate DECIMAL(18,2),
    Runway_Months DECIMAL(8,2),
    Profit DECIMAL(18,2),
    Loss DECIMAL(18,2),
    CAC DECIMAL(12,2),
    LTV DECIMAL(12,2),
    MRR DECIMAL(18,2),
    ARR DECIMAL(18,2),
    Growth_Rate DECIMAL(8,4),
    Market_Size DECIMAL(18,2),
    Competition_Level INT,
    Founder_Experience DECIMAL(6,2),
    Business_Model VARCHAR(100),
    Employee_Satisfaction DECIMAL(4,2),
    Customer_Rating DECIMAL(4,2),
    Customer_Churn DECIMAL(8,4),
    Website_Traffic BIGINT,
    Monthly_Active_Users BIGINT,
    Product_Stage VARCHAR(50),
    Failure_Reason VARCHAR(150),
    Exit_Type VARCHAR(50),
    Status VARCHAR(30),
    Survival_Years DECIMAL(6,2),
    Risk_Score DECIMAL(6,2),
    Failed TINYINT
);

-- Update path before execution.
-- LOAD DATA LOCAL INFILE 'C:/Users/anike/Downloads/project/data/raw/startup_failure_dataset.csv'
-- INTO TABLE stg_startup_failure
-- FIELDS TERMINATED BY ',' ENCLOSED BY '"'
-- LINES TERMINATED BY '\n'
-- IGNORE 1 ROWS;
