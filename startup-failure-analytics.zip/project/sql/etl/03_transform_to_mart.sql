USE startup_failure_analytics;

INSERT IGNORE INTO dim_country (country_name)
SELECT DISTINCT Country FROM stg_startup_failure WHERE Country IS NOT NULL;

INSERT IGNORE INTO dim_city (city_name, country_id)
SELECT DISTINCT s.City, c.country_id
FROM stg_startup_failure s
JOIN dim_country c ON s.Country = c.country_name
WHERE s.City IS NOT NULL;

INSERT IGNORE INTO dim_industry (industry_name)
SELECT DISTINCT Industry FROM stg_startup_failure WHERE Industry IS NOT NULL;

INSERT IGNORE INTO dim_business_model (business_model)
SELECT DISTINCT Business_Model FROM stg_startup_failure WHERE Business_Model IS NOT NULL;

INSERT IGNORE INTO dim_product_stage (product_stage)
SELECT DISTINCT Product_Stage FROM stg_startup_failure WHERE Product_Stage IS NOT NULL;

INSERT IGNORE INTO dim_failure_reason (failure_reason)
SELECT DISTINCT Failure_Reason FROM stg_startup_failure WHERE Failure_Reason IS NOT NULL;

INSERT IGNORE INTO dim_exit_type (exit_type)
SELECT DISTINCT Exit_Type FROM stg_startup_failure WHERE Exit_Type IS NOT NULL;

INSERT INTO fact_startup (
    startup_id, startup_name, country_id, city_id, industry_id, business_model_id,
    product_stage_id, failure_reason_id, exit_type_id, founded_year, closed_year,
    funding_amount, funding_rounds, investors, employees, revenue, expenses,
    burn_rate, runway_months, profit, loss, cac, ltv, mrr, arr, growth_rate,
    market_size, competition_level, founder_experience, employee_satisfaction,
    customer_rating, customer_churn, website_traffic, monthly_active_users,
    status, survival_years, risk_score, failed
)
SELECT
    s.Startup_ID,
    s.Startup_Name,
    c.country_id,
    city.city_id,
    i.industry_id,
    bm.business_model_id,
    ps.product_stage_id,
    fr.failure_reason_id,
    et.exit_type_id,
    s.Founded_Year,
    s.Closed_Year,
    s.Funding_Amount,
    s.Funding_Rounds,
    s.Investors,
    s.Employees,
    s.Revenue,
    s.Expenses,
    s.Burn_Rate,
    s.Runway_Months,
    s.Profit,
    s.Loss,
    s.CAC,
    s.LTV,
    s.MRR,
    s.ARR,
    s.Growth_Rate,
    s.Market_Size,
    s.Competition_Level,
    s.Founder_Experience,
    s.Employee_Satisfaction,
    s.Customer_Rating,
    s.Customer_Churn,
    s.Website_Traffic,
    s.Monthly_Active_Users,
    s.Status,
    s.Survival_Years,
    s.Risk_Score,
    s.Failed
FROM stg_startup_failure s
JOIN dim_country c ON s.Country = c.country_name
JOIN dim_city city ON s.City = city.city_name AND city.country_id = c.country_id
JOIN dim_industry i ON s.Industry = i.industry_name
JOIN dim_business_model bm ON s.Business_Model = bm.business_model
JOIN dim_product_stage ps ON s.Product_Stage = ps.product_stage
JOIN dim_failure_reason fr ON s.Failure_Reason = fr.failure_reason
JOIN dim_exit_type et ON s.Exit_Type = et.exit_type
ON DUPLICATE KEY UPDATE
    risk_score = VALUES(risk_score),
    status = VALUES(status),
    failed = VALUES(failed),
    updated_at = CURRENT_TIMESTAMP;
