"""Business analytics modules."""
