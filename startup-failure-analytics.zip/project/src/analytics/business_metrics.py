from __future__ import annotations

import pandas as pd


def segment_failure_metrics(data: pd.DataFrame, segment_column: str) -> pd.DataFrame:
    return (
        data.groupby(segment_column)
        .agg(
            Total_Startups=("Startup_ID", "count"),
            Failed_Startups=("Failed", "sum"),
            Failure_Rate=("Failed", "mean"),
            Average_Funding=("Funding_Amount", "mean"),
            Average_Revenue=("Revenue", "mean"),
            Average_Burn_Rate=("Burn_Rate", "mean"),
            Average_Risk_Score=("Risk_Score", "mean"),
        )
        .sort_values("Failure_Rate", ascending=False)
        .reset_index()
    )
