from __future__ import annotations

import pandas as pd


def calculate_correlation_matrix(data: pd.DataFrame) -> pd.DataFrame:
    numeric_data = data.select_dtypes(include=["number"])
    return numeric_data.corr(numeric_only=True)


def target_correlations(data: pd.DataFrame, target: str = "Failed") -> pd.Series:
    return calculate_correlation_matrix(data)[target].sort_values(key=lambda values: values.abs(), ascending=False)
