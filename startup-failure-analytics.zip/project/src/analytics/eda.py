from __future__ import annotations

import pandas as pd


def generate_eda_summary(data: pd.DataFrame) -> dict[str, pd.DataFrame]:
    return {
        "shape": pd.DataFrame({"Metric": ["Rows", "Columns"], "Value": [data.shape[0], data.shape[1]]}),
        "missing_values": data.isna().sum().reset_index(name="Missing_Values").rename(columns={"index": "Column"}),
        "numeric_summary": data.describe().transpose().reset_index().rename(columns={"index": "Column"}),
        "status_mix": data["Status"].value_counts().reset_index(name="Startup_Count").rename(columns={"index": "Status"}),
        "industry_mix": data["Industry"].value_counts().reset_index(name="Startup_Count").rename(columns={"index": "Industry"}),
    }
