from __future__ import annotations

import pandas as pd
from scipy.stats import chi2_contingency, mannwhitneyu, ttest_ind


def run_hypothesis_tests(data: pd.DataFrame) -> dict:
    failed = data[data["Failed"] == 1]
    successful = data[data["Failed"] == 0]
    industry_table = pd.crosstab(data["Industry"], data["Failed"])

    return {
        "burn_rate_mann_whitney": mannwhitneyu(failed["Burn_Rate"], successful["Burn_Rate"], alternative="two-sided"),
        "runway_t_test": ttest_ind(failed["Runway_Months"], successful["Runway_Months"], equal_var=False),
        "industry_failure_chi_square": chi2_contingency(industry_table),
    }
