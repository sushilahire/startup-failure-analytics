from __future__ import annotations

import pandas as pd


def calculate_kpis(data: pd.DataFrame) -> pd.Series:
    return pd.Series(
        {
            "Total Startups": len(data),
            "Failed Startups": int(data["Failed"].sum()),
            "Success Rate": 1 - data["Failed"].mean(),
            "Average Funding": data["Funding_Amount"].mean(),
            "Average Survival Years": data["Survival_Years"].mean(),
            "Average Burn Rate": data["Burn_Rate"].mean(),
            "Average Revenue": data["Revenue"].mean(),
            "Average Risk Score": data["Risk_Score"].mean(),
        }
    )
