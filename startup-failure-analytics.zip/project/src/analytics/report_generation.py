from __future__ import annotations

from pathlib import Path

import pandas as pd


def export_excel_report(tables: dict[str, pd.DataFrame | pd.Series], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        for sheet_name, table in tables.items():
            frame = table.to_frame("Value") if isinstance(table, pd.Series) else table
            frame.to_excel(writer, sheet_name=sheet_name[:31], index=not isinstance(table, pd.Series))
