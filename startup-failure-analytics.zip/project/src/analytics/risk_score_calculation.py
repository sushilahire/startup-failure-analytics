from __future__ import annotations

import numpy as np
import pandas as pd


def calculate_risk_score(data: pd.DataFrame) -> pd.Series:
    score = (
        20
        + data["Customer_Churn"] * 35
        + data["Competition_Level"] * 0.2
        + np.where(data["Runway_Months"] < 12, 18, 0)
        + np.where(data["Growth_Rate"] < 0, 12, 0)
        + np.where(data["LTV_CAC_Ratio"] < 3, 10, 0)
        - data["Employee_Satisfaction"] * 2
        - data["Customer_Rating"] * 2
    )
    return pd.Series(np.clip(score, 1, 99), index=data.index, name="Calculated_Risk_Score").round(2)
