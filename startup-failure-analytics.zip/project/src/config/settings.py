from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"
RAW_DATA_PATH = DATA_DIR / "raw" / "startup_failure_dataset.csv"
SAMPLE_DATA_PATH = DATA_DIR / "raw" / "startup_failure_sample.csv"
PROCESSED_DIR = DATA_DIR / "processed"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
FIGURES_DIR = OUTPUT_DIR / "figures"
MODELS_DIR = OUTPUT_DIR / "models"
TABLES_DIR = OUTPUT_DIR / "tables"

TARGET_COLUMN = "Failed"
RANDOM_STATE = 42
TEST_SIZE = 0.25

NUMERIC_FEATURES = [
    "Founded_Year",
    "Funding_Amount",
    "Funding_Rounds",
    "Employees",
    "Revenue",
    "Expenses",
    "Burn_Rate",
    "Runway_Months",
    "Profit",
    "Loss",
    "CAC",
    "LTV",
    "MRR",
    "ARR",
    "Growth_Rate",
    "Market_Size",
    "Competition_Level",
    "Founder_Experience",
    "Employee_Satisfaction",
    "Customer_Rating",
    "Customer_Churn",
    "Website_Traffic",
    "Monthly_Active_Users",
    "Survival_Years",
    "LTV_CAC_Ratio",
    "Capital_Efficiency",
    "Funding_Per_Employee",
    "Traffic_To_MAU_Rate",
]

CATEGORICAL_FEATURES = [
    "Country",
    "City",
    "Industry",
    "Business_Model",
    "Product_Stage",
    "Exit_Type",
    "Status",
]

REQUIRED_COLUMNS = [
    "Startup_ID",
    "Startup_Name",
    "Country",
    "City",
    "Industry",
    "Founded_Year",
    "Closed_Year",
    "Funding_Amount",
    "Funding_Rounds",
    "Investors",
    "Employees",
    "Revenue",
    "Expenses",
    "Burn_Rate",
    "Runway_Months",
    "Profit",
    "Loss",
    "CAC",
    "LTV",
    "MRR",
    "ARR",
    "Growth_Rate",
    "Market_Size",
    "Competition_Level",
    "Founder_Experience",
    "Business_Model",
    "Employee_Satisfaction",
    "Customer_Rating",
    "Customer_Churn",
    "Website_Traffic",
    "Monthly_Active_Users",
    "Product_Stage",
    "Failure_Reason",
    "Exit_Type",
    "Status",
    "Survival_Years",
    "Risk_Score",
    "Failed",
]
