import pandas as pd


REQUIRED_COLUMNS = {
    "startup_id",
    "startup_name",
    "founding_year",
    "country",
    "city",
    "industry",
    "funding_stage",
    "total_funding_usd",
    "team_size",
    "months_active",
    "monthly_burn_usd",
    "monthly_revenue_usd",
    "customer_count",
    "founder_experience_years",
    "market_size_usd_m",
    "competitor_count",
    "product_stage",
    "has_pivoted",
    "status",
}


def validate_schema(data: pd.DataFrame) -> None:
    missing_columns = REQUIRED_COLUMNS.difference(data.columns)
    if missing_columns:
        raise ValueError(f"Missing required columns: {sorted(missing_columns)}")


def clean_startup_data(data: pd.DataFrame) -> pd.DataFrame:
    """Standardize types, labels, and missing values."""
    validate_schema(data)
    cleaned = data.copy()

    text_columns = [
        "startup_id",
        "startup_name",
        "country",
        "city",
        "industry",
        "funding_stage",
        "product_stage",
        "primary_failure_reason",
        "status",
    ]
    for column in text_columns:
        if column in cleaned.columns:
            cleaned[column] = cleaned[column].fillna("Unknown").astype(str).str.strip()

    numeric_columns = [
        "founding_year",
        "total_funding_usd",
        "team_size",
        "months_active",
        "monthly_burn_usd",
        "monthly_revenue_usd",
        "customer_count",
        "founder_experience_years",
        "market_size_usd_m",
        "competitor_count",
    ]
    for column in numeric_columns:
        cleaned[column] = pd.to_numeric(cleaned[column], errors="coerce")
        cleaned[column] = cleaned[column].fillna(cleaned[column].median())

    cleaned["has_pivoted"] = cleaned["has_pivoted"].astype(int)
    cleaned["is_failed"] = (cleaned["status"].str.lower() == "failed").astype(int)
    cleaned = cleaned.drop_duplicates(subset=["startup_id"])
    return cleaned
