from __future__ import annotations

import pandas as pd

from src.data.data_validation import validate_dataset
from src.data.duplicate_removal import remove_duplicate_startups
from src.data.missing_value_handling import handle_missing_values


def clean_dataset(data: pd.DataFrame) -> pd.DataFrame:
    validate_dataset(data)
    cleaned = remove_duplicate_startups(data)
    cleaned = handle_missing_values(cleaned)

    text_columns = cleaned.select_dtypes(exclude=["number"]).columns
    for column in text_columns:
        cleaned[column] = cleaned[column].astype(str).str.strip()

    cleaned["Failed"] = cleaned["Failed"].astype(int)
    return cleaned
