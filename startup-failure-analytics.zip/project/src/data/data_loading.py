from __future__ import annotations

from pathlib import Path

import pandas as pd

from src.config.settings import RAW_DATA_PATH


def load_csv_data(path: Path = RAW_DATA_PATH) -> pd.DataFrame:
    return pd.read_csv(path)


def save_dataframe(data: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data.to_csv(path, index=False)
