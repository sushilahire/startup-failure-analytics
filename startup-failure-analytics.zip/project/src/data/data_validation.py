from __future__ import annotations

import pandas as pd

from src.config.settings import REQUIRED_COLUMNS


def validate_required_columns(data: pd.DataFrame) -> None:
    missing_columns = set(REQUIRED_COLUMNS).difference(data.columns)
    if missing_columns:
        raise ValueError(f"Missing required columns: {sorted(missing_columns)}")


def validate_business_rules(data: pd.DataFrame) -> None:
    invalid_rules = {
        "Funding_Amount must be non-negative": (data["Funding_Amount"] < 0).any(),
        "Employees must be positive": (data["Employees"] <= 0).any(),
        "Failed must be binary": ~data["Failed"].isin([0, 1]).all(),
        "Founded_Year must be valid": ~data["Founded_Year"].between(1990, 2030).all(),
    }
    violations = [rule for rule, failed in invalid_rules.items() if failed]
    if violations:
        raise ValueError(f"Data validation failed: {violations}")


def validate_dataset(data: pd.DataFrame) -> None:
    validate_required_columns(data)
    validate_business_rules(data)
