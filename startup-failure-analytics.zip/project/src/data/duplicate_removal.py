from __future__ import annotations

import pandas as pd


def remove_duplicate_startups(data: pd.DataFrame) -> pd.DataFrame:
    return data.drop_duplicates(subset=["Startup_ID"], keep="first").reset_index(drop=True)
