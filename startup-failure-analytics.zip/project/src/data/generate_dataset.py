from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


RANDOM_SEED = 42
ROW_COUNT = 25000
OUTPUT_PATH = Path("data/raw/startup_failure_dataset.csv")

COUNTRY_CITY = {
    "USA": ["San Francisco", "New York", "Austin", "Boston", "Seattle", "Chicago"],
    "India": ["Bengaluru", "Mumbai", "Delhi", "Hyderabad", "Pune", "Chennai"],
    "UK": ["London", "Manchester", "Cambridge", "Edinburgh"],
    "Germany": ["Berlin", "Munich", "Hamburg", "Frankfurt"],
    "Canada": ["Toronto", "Vancouver", "Montreal", "Waterloo"],
    "Israel": ["Tel Aviv", "Jerusalem", "Haifa"],
    "Singapore": ["Singapore"],
    "Brazil": ["Sao Paulo", "Rio de Janeiro", "Florianopolis"],
    "France": ["Paris", "Lyon", "Toulouse"],
    "Australia": ["Sydney", "Melbourne", "Brisbane"],
}

INDUSTRIES = [
    "FinTech",
    "HealthTech",
    "EdTech",
    "E-commerce",
    "SaaS",
    "AI Tools",
    "Cybersecurity",
    "ClimateTech",
    "Logistics",
    "AgriTech",
    "PropTech",
    "Consumer Apps",
]

BUSINESS_MODELS = ["B2B SaaS", "B2C Subscription", "Marketplace", "Transaction Fee", "Hardware", "Freemium", "Enterprise License"]
PRODUCT_STAGES = ["Prototype", "MVP", "Beta", "Launch", "Growth", "Scale"]
FAILURE_REASONS = [
    "Cash flow issues",
    "Poor product-market fit",
    "High customer acquisition cost",
    "Competitive pressure",
    "Weak unit economics",
    "Founder conflict",
    "Regulatory delays",
    "Operational scaling issues",
    "Technology execution risk",
]
EXIT_TYPES = ["Closed", "Acquired", "IPO", "Merged", "Still Operating"]
INVESTOR_NAMES = [
    "Sequoia Capital",
    "Accel",
    "Andreessen Horowitz",
    "Lightspeed",
    "Tiger Global",
    "SoftBank",
    "Index Ventures",
    "Bessemer Venture Partners",
    "General Catalyst",
    "Insight Partners",
    "Kalaari Capital",
    "Blume Ventures",
    "Local Angels",
    "Corporate Venture Fund",
]


def _sigmoid(value: np.ndarray) -> np.ndarray:
    return 1 / (1 + np.exp(-value))


def _clip_round(values: np.ndarray, minimum: float, maximum: float, decimals: int = 2) -> np.ndarray:
    return np.round(np.clip(values, minimum, maximum), decimals)


def _generate_investors(rng: np.random.Generator, rounds: int) -> str:
    investor_count = int(np.clip(rounds + rng.integers(0, 3), 1, 6))
    return "; ".join(rng.choice(INVESTOR_NAMES, size=investor_count, replace=False))


def build_startup_failure_dataset(row_count: int = ROW_COUNT, seed: int = RANDOM_SEED) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    countries = rng.choice(list(COUNTRY_CITY.keys()), size=row_count, p=[0.28, 0.18, 0.11, 0.09, 0.08, 0.06, 0.05, 0.05, 0.05, 0.05])
    cities = [rng.choice(COUNTRY_CITY[country]) for country in countries]
    industries = rng.choice(INDUSTRIES, size=row_count)
    founded_year = rng.integers(2005, 2025, size=row_count)
    age_potential = 2026 - founded_year

    industry_growth_factor = pd.Series(industries).map(
        {
            "AI Tools": 1.35,
            "Cybersecurity": 1.25,
            "ClimateTech": 1.18,
            "FinTech": 1.12,
            "HealthTech": 1.08,
            "SaaS": 1.06,
            "E-commerce": 0.95,
            "Consumer Apps": 0.9,
        }
    ).fillna(1.0).to_numpy()

    market_size = rng.lognormal(mean=9.5, sigma=0.75, size=row_count) * industry_growth_factor
    competition_level = _clip_round(rng.normal(55, 20, row_count) + (market_size / np.percentile(market_size, 95)) * 10, 1, 100, 0).astype(int)
    founder_experience = _clip_round(rng.gamma(shape=3.0, scale=3.0, size=row_count), 0, 35, 1)
    funding_rounds = np.clip(rng.poisson(lam=2.1, size=row_count) + 1, 1, 10)
    funding_amount = rng.lognormal(mean=14.7 + funding_rounds * 0.22, sigma=1.05, size=row_count)
    funding_amount = _clip_round(funding_amount, 25000, 850000000, 2)

    employees = np.clip((funding_amount / rng.lognormal(11.9, 0.55, row_count)).astype(int), 2, 2500)
    mrr = funding_amount / rng.lognormal(5.2, 0.95, row_count)
    mrr = _clip_round(mrr * industry_growth_factor, 0, 25000000, 2)
    arr = np.round(mrr * 12, 2)
    revenue = _clip_round(arr * rng.uniform(0.65, 1.25, row_count), 0, 350000000, 2)
    expenses = _clip_round((employees * rng.normal(105000, 32000, row_count)) + (funding_amount * rng.uniform(0.06, 0.32, row_count)), 50000, 550000000, 2)
    burn_rate = _clip_round(np.maximum(expenses - revenue, expenses * rng.uniform(0.03, 0.18, row_count)) / 12, 1000, 25000000, 2)
    runway_months = _clip_round(funding_amount / np.maximum(burn_rate, 1), 0.5, 120, 1)
    profit = _clip_round(np.maximum(revenue - expenses, 0), 0, 250000000, 2)
    loss = _clip_round(np.maximum(expenses - revenue, 0), 0, 550000000, 2)

    cac = _clip_round(rng.lognormal(mean=5.2, sigma=0.75, size=row_count) * (competition_level / 50), 8, 8000, 2)
    ltv = _clip_round(cac * rng.lognormal(mean=1.18, sigma=0.55, size=row_count), 20, 90000, 2)
    growth_rate = _clip_round(rng.normal(0.28, 0.34, row_count) + (ltv / np.maximum(cac, 1) - 3) * 0.05, -0.85, 2.8, 4)
    employee_satisfaction = _clip_round(rng.normal(3.45, 0.75, row_count) - (burn_rate / np.percentile(burn_rate, 95)) * 0.35, 1, 5, 2)
    customer_rating = _clip_round(rng.normal(3.7, 0.62, row_count) + growth_rate * 0.16, 1, 5, 2)
    customer_churn = _clip_round(rng.beta(2.2, 7.5, row_count) + np.maximum(0, 3.2 - customer_rating) * 0.07, 0.005, 0.85, 4)
    website_traffic = np.clip((rng.lognormal(10.2, 1.05, row_count) * (1 + np.maximum(growth_rate, -0.5))).astype(int), 50, 25000000)
    monthly_active_users = np.clip((website_traffic * rng.beta(2.0, 7.0, row_count)).astype(int), 5, 12000000)

    risk_signal = (
        1.2 * (burn_rate / np.percentile(burn_rate, 90))
        - 1.0 * (runway_months / 36)
        + 1.1 * customer_churn
        - 0.55 * growth_rate
        + 0.009 * competition_level
        - 0.08 * founder_experience
        - 0.28 * np.log1p(ltv / np.maximum(cac, 1))
        - 0.18 * employee_satisfaction
        - 0.16 * customer_rating
    )
    failed_probability = _sigmoid(risk_signal + rng.normal(0, 0.45, row_count))
    failed = rng.binomial(1, np.clip(failed_probability, 0.03, 0.94))
    risk_score = _clip_round(failed_probability * 100, 1, 99, 2)

    survival_years = _clip_round(
        np.where(
            failed == 1,
            rng.uniform(0.4, np.minimum(age_potential, 11) + 0.5),
            np.maximum(1, age_potential - rng.uniform(0, 2.5, row_count)),
        ),
        0.2,
        21,
        1,
    )
    closed_year = np.where(failed == 1, np.minimum(2026, founded_year + np.ceil(survival_years).astype(int)), np.nan)
    closed_year = pd.Series(closed_year).astype("Int64")

    product_stage = np.select(
        [
            survival_years <= 1.5,
            survival_years <= 2.5,
            survival_years <= 4,
            survival_years <= 6,
            survival_years <= 9,
        ],
        PRODUCT_STAGES[:-1],
        default="Scale",
    )
    status = np.where(failed == 1, "Failed", "Active")
    high_quality_exit = (failed == 0) & (funding_amount > np.percentile(funding_amount, 88)) & (growth_rate > 0.35)
    exit_type = np.where(failed == 1, "Closed", "Still Operating")
    exit_type = np.where(high_quality_exit & (rng.random(row_count) < 0.58), "Acquired", exit_type)
    exit_type = np.where(high_quality_exit & (rng.random(row_count) < 0.07), "IPO", exit_type)
    exit_type = np.where((failed == 0) & (rng.random(row_count) < 0.025), "Merged", exit_type)
    status = np.where(np.isin(exit_type, ["Acquired", "IPO", "Merged"]), "Exited", status)

    failure_reason = rng.choice(FAILURE_REASONS, size=row_count, p=[0.19, 0.18, 0.14, 0.12, 0.11, 0.07, 0.06, 0.08, 0.05])
    failure_reason = np.where(failed == 1, failure_reason, "Not Applicable")
    business_model = rng.choice(BUSINESS_MODELS, size=row_count)

    company_prefix = rng.choice(["Nova", "Pulse", "Apex", "Quantum", "Bright", "Urban", "Cloud", "Swift", "Green", "Vertex"], size=row_count)
    company_suffix = rng.choice(["Labs", "Works", "AI", "Systems", "Hub", "Base", "Flow", "Loop", "Stack", "Grid"], size=row_count)
    startup_name = [f"{prefix}{suffix}{index:05d}" for index, (prefix, suffix) in enumerate(zip(company_prefix, company_suffix), start=1)]
    investors = [_generate_investors(rng, int(rounds)) for rounds in funding_rounds]

    return pd.DataFrame(
        {
            "Startup_ID": [f"ST{index:06d}" for index in range(1, row_count + 1)],
            "Startup_Name": startup_name,
            "Country": countries,
            "City": cities,
            "Industry": industries,
            "Founded_Year": founded_year,
            "Closed_Year": closed_year,
            "Funding_Amount": funding_amount,
            "Funding_Rounds": funding_rounds,
            "Investors": investors,
            "Employees": employees,
            "Revenue": revenue,
            "Expenses": expenses,
            "Burn_Rate": burn_rate,
            "Runway_Months": runway_months,
            "Profit": profit,
            "Loss": loss,
            "CAC": cac,
            "LTV": ltv,
            "MRR": mrr,
            "ARR": arr,
            "Growth_Rate": growth_rate,
            "Market_Size": _clip_round(market_size, 50, 750000, 2),
            "Competition_Level": competition_level,
            "Founder_Experience": founder_experience,
            "Business_Model": business_model,
            "Employee_Satisfaction": employee_satisfaction,
            "Customer_Rating": customer_rating,
            "Customer_Churn": customer_churn,
            "Website_Traffic": website_traffic,
            "Monthly_Active_Users": monthly_active_users,
            "Product_Stage": product_stage,
            "Failure_Reason": failure_reason,
            "Exit_Type": exit_type,
            "Status": status,
            "Survival_Years": survival_years,
            "Risk_Score": risk_score,
            "Failed": failed,
        }
    )


def main() -> None:
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    dataset = build_startup_failure_dataset()
    dataset.to_csv(OUTPUT_PATH, index=False)
    print(f"Generated {len(dataset):,} rows at {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
