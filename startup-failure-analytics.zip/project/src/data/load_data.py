import pandas as pd

from src.config.settings import RAW_DATA_PATH


def load_startup_data(path=RAW_DATA_PATH) -> pd.DataFrame:
    """Load startup outcome data from CSV."""
    return pd.read_csv(path)


if __name__ == "__main__":
    data = load_startup_data()
    print(data.head())
