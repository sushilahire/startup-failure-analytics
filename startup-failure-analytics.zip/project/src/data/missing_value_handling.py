from __future__ import annotations

import pandas as pd


def handle_missing_values(data: pd.DataFrame) -> pd.DataFrame:
    cleaned = data.copy()
    numeric_columns = cleaned.select_dtypes(include=["number"]).columns
    categorical_columns = cleaned.select_dtypes(exclude=["number"]).columns

    for column in numeric_columns:
        cleaned[column] = cleaned[column].fillna(cleaned[column].median())

    for column in categorical_columns:
        cleaned[column] = cleaned[column].fillna("Unknown")

    if "Closed_Year" in data.columns:
        cleaned["Closed_Year"] = data["Closed_Year"]

    return cleaned
