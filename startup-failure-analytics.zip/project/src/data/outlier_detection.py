from __future__ import annotations

import pandas as pd


def detect_iqr_outliers(data: pd.DataFrame, columns: list[str], multiplier: float = 1.5) -> pd.DataFrame:
    outlier_flags = pd.DataFrame(index=data.index)
    for column in columns:
        q1 = data[column].quantile(0.25)
        q3 = data[column].quantile(0.75)
        iqr = q3 - q1
        lower_bound = q1 - multiplier * iqr
        upper_bound = q3 + multiplier * iqr
        outlier_flags[f"{column}_Outlier"] = ~data[column].between(lower_bound, upper_bound)
    return outlier_flags


def cap_outliers(data: pd.DataFrame, columns: list[str], lower: float = 0.01, upper: float = 0.99) -> pd.DataFrame:
    capped = data.copy()
    for column in columns:
        capped[column] = capped[column].clip(capped[column].quantile(lower), capped[column].quantile(upper))
    return capped
