import numpy as np
import pandas as pd


def build_features(data: pd.DataFrame) -> pd.DataFrame:
    """Create business features used in BI and predictive modeling."""
    features = data.copy()
    revenue = features["monthly_revenue_usd"].replace(0, np.nan)
    burn = features["monthly_burn_usd"].replace(0, np.nan)
    months = features["months_active"].replace(0, np.nan)
    team_size = features["team_size"].replace(0, np.nan)

    features["burn_to_revenue_ratio"] = (features["monthly_burn_usd"] / revenue).replace([np.inf, -np.inf], np.nan)
    features["runway_months"] = (features["total_funding_usd"] / burn).replace([np.inf, -np.inf], np.nan)
    features["customers_per_month"] = (features["customer_count"] / months).replace([np.inf, -np.inf], np.nan)
    features["funding_per_employee"] = (features["total_funding_usd"] / team_size).replace([np.inf, -np.inf], np.nan)
    features["capital_efficiency_score"] = features["monthly_revenue_usd"] / (features["monthly_burn_usd"] + 1)
    features["market_competition_intensity"] = features["competitor_count"] / (features["market_size_usd_m"] + 1)

    engineered_columns = [
        "burn_to_revenue_ratio",
        "runway_months",
        "customers_per_month",
        "funding_per_employee",
        "capital_efficiency_score",
        "market_competition_intensity",
    ]
    for column in engineered_columns:
        features[column] = features[column].fillna(features[column].median())

    return features
