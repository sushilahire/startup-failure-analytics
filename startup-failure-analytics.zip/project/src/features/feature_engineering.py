from __future__ import annotations

import numpy as np
import pandas as pd


def engineer_features(data: pd.DataFrame) -> pd.DataFrame:
    features = data.copy()
    features["LTV_CAC_Ratio"] = features["LTV"] / features["CAC"].replace(0, np.nan)
    features["Capital_Efficiency"] = features["Revenue"] / features["Funding_Amount"].replace(0, np.nan)
    features["Funding_Per_Employee"] = features["Funding_Amount"] / features["Employees"].replace(0, np.nan)
    features["Traffic_To_MAU_Rate"] = features["Monthly_Active_Users"] / features["Website_Traffic"].replace(0, np.nan)
    features["Burn_Multiple"] = features["Burn_Rate"] / features["MRR"].replace(0, np.nan)
    features["Revenue_Expense_Ratio"] = features["Revenue"] / features["Expenses"].replace(0, np.nan)

    engineered_columns = [
        "LTV_CAC_Ratio",
        "Capital_Efficiency",
        "Funding_Per_Employee",
        "Traffic_To_MAU_Rate",
        "Burn_Multiple",
        "Revenue_Expense_Ratio",
    ]
    for column in engineered_columns:
        features[column] = features[column].replace([np.inf, -np.inf], np.nan)
        features[column] = features[column].fillna(features[column].median())

    return features
