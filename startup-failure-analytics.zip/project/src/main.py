from src.analytics.business_metrics import segment_failure_metrics
from src.analytics.correlation_analysis import calculate_correlation_matrix, target_correlations
from src.analytics.eda import generate_eda_summary
from src.analytics.hypothesis_testing import run_hypothesis_tests
from src.analytics.kpi_calculation import calculate_kpis
from src.analytics.report_generation import export_excel_report
from src.analytics.risk_score_calculation import calculate_risk_score
from src.config.settings import CATEGORICAL_FEATURES, NUMERIC_FEATURES, PROCESSED_DIR, TABLES_DIR
from src.data.data_cleaning import clean_dataset
from src.data.data_loading import load_csv_data, save_dataframe
from src.data.outlier_detection import cap_outliers, detect_iqr_outliers
from src.features.feature_engineering import engineer_features
from src.models.feature_importance import extract_feature_importance
from src.models.model_evaluation import evaluate_models, select_best_model
from src.models.model_training import save_best_model, train_models
from src.models.prediction import predict_failure_risk
from src.models.shap_explainability import generate_shap_importance
from src.visualization.visualization import create_visualizations


def run_pipeline() -> None:
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    TABLES_DIR.mkdir(parents=True, exist_ok=True)

    raw_data = load_csv_data()
    clean_data = clean_dataset(raw_data)
    feature_data = engineer_features(clean_data)
    feature_data["Calculated_Risk_Score"] = calculate_risk_score(feature_data)

    capped_columns = ["Funding_Amount", "Revenue", "Expenses", "Burn_Rate", "ARR", "Website_Traffic"]
    modeled_data = cap_outliers(feature_data, capped_columns)
    save_dataframe(clean_data, PROCESSED_DIR / "startup_clean.csv")
    save_dataframe(modeled_data, PROCESSED_DIR / "startup_features.csv")
    modeled_data.to_excel(PROCESSED_DIR / "model_scoring_output.xlsx", index=False)

    create_visualizations(modeled_data)

    models, split_data = train_models(modeled_data)
    x_train, x_test, y_train, y_test = split_data
    model_metrics = evaluate_models(models, x_train, x_test, y_train, y_test)
    best_model_name, best_model = select_best_model(models, model_metrics)
    save_best_model(best_model, best_model_name)

    predictions = predict_failure_risk(best_model, modeled_data)
    feature_importance = extract_feature_importance(best_model)
    shap_importance = generate_shap_importance(best_model, modeled_data[NUMERIC_FEATURES + CATEGORICAL_FEATURES])
    outliers = detect_iqr_outliers(modeled_data, capped_columns)
    eda_summary = generate_eda_summary(modeled_data)
    hypothesis_results = run_hypothesis_tests(modeled_data)

    report_tables = {
        "KPIs": calculate_kpis(modeled_data),
        "Model Comparison": model_metrics,
        "Predictions": predictions.head(500),
        "Feature Importance": feature_importance.head(100),
        "SHAP Importance": shap_importance.head(100),
        "Industry Metrics": segment_failure_metrics(modeled_data, "Industry"),
        "Country Metrics": segment_failure_metrics(modeled_data, "Country"),
        "Target Correlations": target_correlations(modeled_data),
        "Correlation Matrix": calculate_correlation_matrix(modeled_data),
        "Outlier Flags": outliers.sum().to_frame("Outlier_Count"),
        "Hypothesis Tests": _format_hypothesis_results(hypothesis_results),
        **eda_summary,
    }
    export_excel_report(report_tables, TABLES_DIR / "startup_failure_analytics_report.xlsx")
    model_metrics.to_excel(TABLES_DIR / "model_performance.xlsx", index=False)
    feature_importance.to_excel(TABLES_DIR / "feature_importance.xlsx", index=False)
    predictions.to_excel(TABLES_DIR / "startup_failure_predictions.xlsx", index=False)

    print("Startup Failure Analytics pipeline completed.")
    print(f"Best model: {best_model_name} with ROC-AUC {model_metrics.iloc[0]['ROC_AUC']:.3f}")


def _format_hypothesis_results(results: dict) -> object:
    rows = []
    for test_name, result in results.items():
        if test_name == "industry_failure_chi_square":
            statistic, p_value, degrees_of_freedom, _ = result
        else:
            statistic, p_value = result.statistic, result.pvalue
            degrees_of_freedom = None
        rows.append(
            {
                "Test": test_name,
                "Statistic": statistic,
                "P_Value": p_value,
                "Degrees_Of_Freedom": degrees_of_freedom,
            }
        )
    import pandas as pd

    return pd.DataFrame(rows)


if __name__ == "__main__":
    run_pipeline()
