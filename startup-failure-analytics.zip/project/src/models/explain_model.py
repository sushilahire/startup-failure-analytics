import pandas as pd

from src.config.settings import CATEGORICAL_FEATURES, NUMERIC_FEATURES


def calculate_shap_summary(model_pipeline, data: pd.DataFrame, sample_size: int = 100) -> pd.DataFrame:
    """Calculate global SHAP importance when the fitted model supports it."""
    features = data[NUMERIC_FEATURES + CATEGORICAL_FEATURES].head(sample_size)
    preprocessor = model_pipeline.named_steps["preprocessor"]
    model = model_pipeline.named_steps["model"]
    transformed = preprocessor.transform(features)
    feature_names = preprocessor.get_feature_names_out()

    try:
        import shap

        explainer = shap.Explainer(model)
        shap_values = explainer(transformed)
        values = abs(shap_values.values).mean(axis=0)
        return pd.DataFrame({"feature": feature_names, "mean_abs_shap": values}).sort_values(
            "mean_abs_shap", ascending=False
        )
    except Exception:
        if hasattr(model, "feature_importances_"):
            values = model.feature_importances_
            return pd.DataFrame({"feature": feature_names, "mean_abs_shap": values}).sort_values(
                "mean_abs_shap", ascending=False
            )
        return pd.DataFrame(columns=["feature", "mean_abs_shap"])
