from __future__ import annotations

import pandas as pd
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import cross_val_score

from src.config.settings import RANDOM_STATE


def evaluate_model(model, x_test: pd.DataFrame, y_test: pd.Series) -> dict:
    predictions = model.predict(x_test)
    probabilities = model.predict_proba(x_test)[:, 1]
    return {
        "Accuracy": accuracy_score(y_test, predictions),
        "Precision": precision_score(y_test, predictions, zero_division=0),
        "Recall": recall_score(y_test, predictions, zero_division=0),
        "F1": f1_score(y_test, predictions, zero_division=0),
        "ROC_AUC": roc_auc_score(y_test, probabilities),
        "Confusion_Matrix": confusion_matrix(y_test, predictions).tolist(),
    }


def evaluate_models(models: dict, x_train: pd.DataFrame, x_test: pd.DataFrame, y_train: pd.Series, y_test: pd.Series) -> pd.DataFrame:
    rows = []
    for model_name, model in models.items():
        metrics = evaluate_model(model, x_test, y_test)
        cv_scores = cross_val_score(model, x_train, y_train, cv=5, scoring="roc_auc", n_jobs=-1)
        metrics["Model"] = model_name
        metrics["CV_ROC_AUC_Mean"] = cv_scores.mean()
        metrics["CV_ROC_AUC_Std"] = cv_scores.std()
        rows.append(metrics)
    return pd.DataFrame(rows).sort_values("ROC_AUC", ascending=False).reset_index(drop=True)


def select_best_model(models: dict, evaluation_results: pd.DataFrame):
    best_model_name = evaluation_results.iloc[0]["Model"]
    return best_model_name, models[best_model_name]
