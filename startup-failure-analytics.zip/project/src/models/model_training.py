from __future__ import annotations

import pickle
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier
from xgboost import XGBClassifier

from src.config.settings import CATEGORICAL_FEATURES, MODELS_DIR, NUMERIC_FEATURES, RANDOM_STATE, TARGET_COLUMN, TEST_SIZE


def build_preprocessor() -> ColumnTransformer:
    numeric_pipeline = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())])
    categorical_pipeline = Pipeline([("imputer", SimpleImputer(strategy="most_frequent")), ("encoder", OneHotEncoder(handle_unknown="ignore"))])
    return ColumnTransformer(
        transformers=[
            ("numeric", numeric_pipeline, NUMERIC_FEATURES),
            ("categorical", categorical_pipeline, CATEGORICAL_FEATURES),
        ]
    )


def get_models() -> dict[str, object]:
    return {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=RANDOM_STATE),
        "Decision Tree": DecisionTreeClassifier(max_depth=8, min_samples_leaf=50, random_state=RANDOM_STATE),
        "Random Forest": RandomForestClassifier(n_estimators=250, max_depth=10, min_samples_leaf=25, random_state=RANDOM_STATE, n_jobs=-1),
        "Gradient Boosting": GradientBoostingClassifier(n_estimators=180, learning_rate=0.06, max_depth=3, random_state=RANDOM_STATE),
        "XGBoost": XGBClassifier(
            n_estimators=220,
            max_depth=4,
            learning_rate=0.05,
            subsample=0.9,
            colsample_bytree=0.9,
            eval_metric="logloss",
            random_state=RANDOM_STATE,
            n_jobs=-1,
        ),
    }


def split_features_target(data: pd.DataFrame):
    features = data[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
    target = data[TARGET_COLUMN]
    return train_test_split(features, target, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=target)


def train_models(data: pd.DataFrame) -> tuple[dict[str, Pipeline], tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]]:
    x_train, x_test, y_train, y_test = split_features_target(data)
    fitted_models = {}

    for model_name, estimator in get_models().items():
        pipeline = Pipeline([("preprocessor", build_preprocessor()), ("model", estimator)])
        pipeline.fit(x_train, y_train)
        fitted_models[model_name] = pipeline

    return fitted_models, (x_train, x_test, y_train, y_test)


def save_best_model(model: Pipeline, model_name: str) -> None:
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    with (MODELS_DIR / "best_startup_failure_model.pkl").open("wb") as model_file:
        pickle.dump(model, model_file)
    (MODELS_DIR / "best_model_name.txt").write_text(model_name, encoding="utf-8")
