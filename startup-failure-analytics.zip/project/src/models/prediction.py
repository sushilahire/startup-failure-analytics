from __future__ import annotations

import pandas as pd

from src.config.settings import CATEGORICAL_FEATURES, NUMERIC_FEATURES


def predict_failure_risk(model, data: pd.DataFrame) -> pd.DataFrame:
    predictions = data[["Startup_ID", "Startup_Name", "Industry", "Country"]].copy()
    model_features = data[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
    predictions["Predicted_Failed"] = model.predict(model_features)
    predictions["Failure_Probability"] = model.predict_proba(model_features)[:, 1]
    return predictions.sort_values("Failure_Probability", ascending=False)
