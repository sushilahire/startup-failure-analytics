from __future__ import annotations

import pandas as pd


def generate_shap_importance(model_pipeline, data: pd.DataFrame, sample_size: int = 1000) -> pd.DataFrame:
    try:
        import shap
    except ImportError:
        return pd.DataFrame(columns=["Feature", "Mean_ABS_SHAP"])

    sample = data.sample(min(sample_size, len(data)), random_state=42)
    preprocessor = model_pipeline.named_steps["preprocessor"]
    model = model_pipeline.named_steps["model"]
    transformed = preprocessor.transform(sample)
    feature_names = preprocessor.get_feature_names_out()

    explainer = shap.Explainer(model)
    shap_values = explainer(transformed)
    values = abs(shap_values.values).mean(axis=0)
    return pd.DataFrame({"Feature": feature_names, "Mean_ABS_SHAP": values}).sort_values("Mean_ABS_SHAP", ascending=False)
