from pathlib import Path

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from xgboost import XGBClassifier

from src.config.settings import CATEGORICAL_FEATURES, NUMERIC_FEATURES, RANDOM_STATE, TARGET_COLUMN, TEST_SIZE


def _build_preprocessor() -> ColumnTransformer:
    numeric_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )
    categorical_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("encoder", OneHotEncoder(handle_unknown="ignore")),
        ]
    )
    return ColumnTransformer(
        transformers=[
            ("numeric", numeric_pipeline, NUMERIC_FEATURES),
            ("categorical", categorical_pipeline, CATEGORICAL_FEATURES),
        ]
    )


def get_candidate_models() -> dict:
    return {
        "logistic_regression": LogisticRegression(max_iter=1000, random_state=RANDOM_STATE),
        "random_forest": RandomForestClassifier(n_estimators=250, max_depth=6, random_state=RANDOM_STATE),
        "xgboost": XGBClassifier(
            n_estimators=150,
            max_depth=3,
            learning_rate=0.08,
            subsample=0.9,
            colsample_bytree=0.9,
            eval_metric="logloss",
            random_state=RANDOM_STATE,
        ),
    }


def train_failure_models(data: pd.DataFrame) -> tuple[dict, pd.DataFrame, Pipeline]:
    """Train candidate classifiers and return metrics plus the best model."""
    x = data[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
    y = data[TARGET_COLUMN]

    stratify = y if y.nunique() > 1 and y.value_counts().min() >= 2 else None
    x_train, x_test, y_train, y_test = train_test_split(
        x,
        y,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=stratify,
    )

    results = []
    fitted_models = {}
    for model_name, model in get_candidate_models().items():
        pipeline = Pipeline(steps=[("preprocessor", _build_preprocessor()), ("model", model)])
        pipeline.fit(x_train, y_train)
        predictions = pipeline.predict(x_test)
        probabilities = pipeline.predict_proba(x_test)[:, 1]
        roc_auc = roc_auc_score(y_test, probabilities) if y_test.nunique() > 1 else 0.5

        results.append(
            {
                "model": model_name,
                "accuracy": accuracy_score(y_test, predictions),
                "roc_auc": roc_auc,
                "confusion_matrix": confusion_matrix(y_test, predictions).tolist(),
                "classification_report": classification_report(y_test, predictions, zero_division=0),
            }
        )
        fitted_models[model_name] = pipeline

    metrics = pd.DataFrame(results).sort_values("roc_auc", ascending=False)
    best_model_name = metrics.iloc[0]["model"]
    return fitted_models, metrics, fitted_models[best_model_name]


def save_model_metrics(metrics: pd.DataFrame, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    metrics.to_excel(output_path, index=False)
