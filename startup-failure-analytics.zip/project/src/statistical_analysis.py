import pandas as pd
from scipy.stats import chi2_contingency, mannwhitneyu
import statsmodels.api as sm


def run_statistical_tests(data: pd.DataFrame) -> dict:
    """Run diagnostic tests for common startup failure hypotheses."""
    failed = data[data["is_failed"] == 1]
    survived = data[data["is_failed"] == 0]

    burn_test = mannwhitneyu(
        failed["burn_to_revenue_ratio"],
        survived["burn_to_revenue_ratio"],
        alternative="two-sided",
    )
    industry_table = pd.crosstab(data["industry"], data["status"])
    chi2, p_value, dof, _ = chi2_contingency(industry_table)

    predictors = sm.add_constant(data[["burn_to_revenue_ratio", "runway_months", "competitor_count"]])
    logistic_model = sm.Logit(data["is_failed"], predictors).fit(disp=False)

    return {
        "mann_whitney_burn_to_revenue_statistic": burn_test.statistic,
        "mann_whitney_burn_to_revenue_p_value": burn_test.pvalue,
        "industry_status_chi2": chi2,
        "industry_status_p_value": p_value,
        "industry_status_degrees_of_freedom": dof,
        "logit_summary": logistic_model.summary2().tables[1],
    }
