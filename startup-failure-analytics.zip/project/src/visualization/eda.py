import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from src.config.settings import FIGURES_DIR


def create_eda_charts(data: pd.DataFrame) -> None:
    """Export core EDA charts for reports and stakeholder review."""
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid")

    plt.figure(figsize=(9, 5))
    failure_by_industry = data.groupby("industry")["is_failed"].mean().sort_values(ascending=False)
    sns.barplot(x=failure_by_industry.values, y=failure_by_industry.index, color="#2f5597")
    plt.xlabel("Failure Rate")
    plt.ylabel("Industry")
    plt.title("Startup Failure Rate by Industry")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "failure_rate_by_industry.png", dpi=160)
    plt.close()

    plt.figure(figsize=(8, 5))
    sns.scatterplot(
        data=data,
        x="burn_to_revenue_ratio",
        y="runway_months",
        hue="status",
        size="total_funding_usd",
        sizes=(40, 300),
    )
    plt.title("Burn Efficiency vs Runway")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "burn_efficiency_vs_runway.png", dpi=160)
    plt.close()

    plt.figure(figsize=(9, 5))
    reasons = data.loc[data["is_failed"] == 1, "primary_failure_reason"].value_counts()
    sns.barplot(x=reasons.values, y=reasons.index, color="#c00000")
    plt.xlabel("Failed Startups")
    plt.ylabel("Primary Failure Reason")
    plt.title("Why Startups Fail")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "failure_reasons.png", dpi=160)
    plt.close()
