from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from src.config.settings import FIGURES_DIR


def create_visualizations(data: pd.DataFrame, output_dir: Path = FIGURES_DIR) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid")

    plt.figure(figsize=(11, 6))
    industry_failure = data.groupby("Industry")["Failed"].mean().sort_values(ascending=False)
    sns.barplot(x=industry_failure.values, y=industry_failure.index, color="#1f4e79")
    plt.title("Failure Rate by Industry")
    plt.xlabel("Failure Rate")
    plt.ylabel("Industry")
    plt.tight_layout()
    plt.savefig(output_dir / "failure_rate_by_industry.png", dpi=160)
    plt.close()

    plt.figure(figsize=(10, 6))
    sns.scatterplot(data=data.sample(min(len(data), 3000), random_state=42), x="Runway_Months", y="Burn_Rate", hue="Failed", alpha=0.65)
    plt.title("Runway vs Burn Rate")
    plt.tight_layout()
    plt.savefig(output_dir / "runway_vs_burn_rate.png", dpi=160)
    plt.close()

    plt.figure(figsize=(11, 6))
    reasons = data.loc[data["Failed"] == 1, "Failure_Reason"].value_counts().head(10)
    sns.barplot(x=reasons.values, y=reasons.index, color="#b22222")
    plt.title("Top Failure Reasons")
    plt.xlabel("Failed Startups")
    plt.ylabel("Failure Reason")
    plt.tight_layout()
    plt.savefig(output_dir / "top_failure_reasons.png", dpi=160)
    plt.close()
