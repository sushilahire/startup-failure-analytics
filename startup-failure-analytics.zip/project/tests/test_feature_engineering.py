import pandas as pd

from src.data.clean_data import clean_startup_data
from src.features.build_features import build_features


def test_feature_engineering_creates_business_metrics():
    data = pd.DataFrame(
        [
            {
                "startup_id": "S1",
                "startup_name": "TestCo",
                "founding_year": 2020,
                "country": "USA",
                "city": "Austin",
                "industry": "FinTech",
                "funding_stage": "Seed",
                "total_funding_usd": 1000000,
                "team_size": 10,
                "months_active": 20,
                "monthly_burn_usd": 100000,
                "monthly_revenue_usd": 50000,
                "customer_count": 40,
                "founder_experience_years": 5,
                "market_size_usd_m": 1000,
                "competitor_count": 20,
                "product_stage": "MVP",
                "has_pivoted": 1,
                "primary_failure_reason": "Cash flow issues",
                "status": "Failed",
            }
        ]
    )

    features = build_features(clean_startup_data(data))

    assert features.loc[0, "is_failed"] == 1
    assert features.loc[0, "burn_to_revenue_ratio"] == 2
    assert features.loc[0, "runway_months"] == 10
    assert features.loc[0, "customers_per_month"] == 2
